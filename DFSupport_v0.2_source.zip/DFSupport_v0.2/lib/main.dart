import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const DFSupportApp());

class DFSupportApp extends StatelessWidget {
  const DFSupportApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'DFSupport',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFF176B5B)),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static const channel = MethodChannel('dfsupport/notifications');
  Timer? timer;
  Map<String, dynamic>? notice;
  double? fee, minutes, km;
  final feeCtl = TextEditingController();
  final minCtl = TextEditingController();
  final kmCtl = TextEditingController();

  @override void initState() { super.initState(); _refresh(); timer = Timer.periodic(const Duration(seconds: 1), (_) => _refresh()); }
  @override void dispose() { timer?.cancel(); feeCtl.dispose(); minCtl.dispose(); kmCtl.dispose(); super.dispose(); }

  Future<void> _refresh() async {
    try {
      final raw = await channel.invokeMapMethod<String, dynamic>('getLatestNotification');
      if (!mounted || raw == null) return;
      final m = Map<String, dynamic>.from(raw);
      if (m['timestamp'] != notice?['timestamp']) {
        notice = m;
        _parse([m['title'], m['text'], m['bigText'], m['textLines']].whereType<String>().join(' '));
        setState(() {});
      }
    } catch (_) {}
  }

  void _parse(String s) {
    final normalized = s.replaceAll(',', '');
    final yen = RegExp(r'(?:¥|￥)\s*([0-9]+(?:\.[0-9]+)?)').firstMatch(normalized);
    final mins = RegExp(r'([0-9]+(?:\.[0-9]+)?)\s*(?:分|min(?:ute)?s?)', caseSensitive: false).firstMatch(normalized);
    final dist = RegExp(r'([0-9]+(?:\.[0-9]+)?)\s*km', caseSensitive: false).firstMatch(normalized);
    fee = double.tryParse(yen?.group(1) ?? '');
    minutes = double.tryParse(mins?.group(1) ?? '');
    km = double.tryParse(dist?.group(1) ?? '');
  }

  double? get hourly => (fee != null && minutes != null && minutes! > 0) ? fee! / minutes! * 60 : null;
  double? get perMin => (fee != null && minutes != null && minutes! > 0) ? fee! / minutes! : null;
  double? get perKm => (fee != null && km != null && km! > 0) ? fee! / km! : null;

  void _manual() {
    setState(() {
      fee = double.tryParse(feeCtl.text.replaceAll(',', ''));
      minutes = double.tryParse(minCtl.text);
      km = double.tryParse(kmCtl.text);
    });
  }

  Widget metric(String label, double? value, String suffix, {int digits = 0}) => Expanded(child: Card(child: Padding(
    padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 8),
    child: Column(children: [Text(label, style: const TextStyle(fontSize: 13)), const SizedBox(height: 6), Text(value == null ? '—' : '${value.toStringAsFixed(digits)}$suffix', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 20))]),
  )));

  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('DFSupport'), actions: [IconButton(onPressed: () => channel.invokeMethod('openNotificationAccess'), icon: const Icon(Icons.notifications_active_outlined), tooltip: '通知アクセス設定')]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('Delivery Fee Support', style: TextStyle(fontSize: 13)),
        const SizedBox(height: 16),
        Row(children: [metric('時間単価', hourly, '円/h'), metric('分単価', perMin, '円/分', digits: 1), metric('距離単価', perKm, '円/km')]),
        const SizedBox(height: 18),
        const Text('手動クイック計算', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: TextField(controller: feeCtl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: '報酬 ¥', border: OutlineInputBorder()), onChanged: (_) => _manual())),
          const SizedBox(width: 8),
          Expanded(child: TextField(controller: minCtl, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: '時間 分', border: OutlineInputBorder()), onChanged: (_) => _manual())),
          const SizedBox(width: 8),
          Expanded(child: TextField(controller: kmCtl, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: '距離 km', border: OutlineInputBorder()), onChanged: (_) => _manual())),
        ]),
        const SizedBox(height: 24),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('最新の通知解析', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)), TextButton(onPressed: () => channel.invokeMethod('openNotificationAccess'), child: const Text('通知アクセス設定'))]),
        Card(child: Padding(padding: const EdgeInsets.all(14), child: SelectableText(notice == null ? 'まだ通知を取得していません。\n右上から通知アクセスを許可してください。' : 'アプリ: ${notice!['packageName'] ?? ''}\nタイトル: ${notice!['title'] ?? ''}\n本文: ${notice!['text'] ?? ''}\n詳細: ${notice!['bigText'] ?? ''}\n行: ${notice!['textLines'] ?? ''}'))),
        const SizedBox(height: 8),
        const Text('※ 初期テスト版。通知に報酬・分・kmが含まれている場合だけ自動抽出します。', style: TextStyle(fontSize: 12)),
      ]),
    );
  }
}
