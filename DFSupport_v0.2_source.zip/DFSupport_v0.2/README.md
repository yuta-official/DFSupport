# DFSupport
Delivery Fee Support prototype for Android.

This test build listens to Android notifications after the user explicitly enables Notification Access. It shows the latest notification payload and attempts to extract fee, minutes and kilometers to calculate hourly, per-minute and per-km rates.

## Build
GitHub Actions > Build DFSupport APK > Run workflow.
