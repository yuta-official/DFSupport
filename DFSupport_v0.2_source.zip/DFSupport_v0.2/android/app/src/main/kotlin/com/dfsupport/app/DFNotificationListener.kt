package com.dfsupport.app

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class DFNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val e = sbn.notification.extras
        val lines = e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.joinToString(" | ") { it.toString() } ?: ""
        NotificationStore.latest = mapOf(
            "packageName" to sbn.packageName,
            "title" to (e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""),
            "text" to (e.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""),
            "bigText" to (e.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString() ?: ""),
            "textLines" to lines,
            "timestamp" to sbn.postTime
        )
    }
}
