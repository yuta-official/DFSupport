package com.dfsupport.app

object NotificationStore {
    @Volatile var latest: Map<String, Any?>? = null
}
